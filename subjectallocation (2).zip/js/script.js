$(document).ready(function () {
  $(document).on("click", ".sign li", function () {
    $(".sign li").removeClass("active");
    $(".box").hide();
    $(".box").eq($(this).index()).show();
    $(".sign li").eq($(this).index()).addClass("active");
  });

  $(document).on("click", "#signup", function () {
    $(".popup-overlay").toggleClass("open");
  });
  $(document).on("click", ".btnstyle.ident", function () {
    if ($(".valotp").val() != "") {
      $(this).addClass("load");
      setTimeout(function () {
        $("#openbox").removeClass("open");
      }, 1500);
    } else {
      $(".mandatory-field").addClass("err");
    }
  });
  $(document).on("click", ".btnstyle.toprd", function () {
    $(this).addClass("load");
    setTimeout(function () {
      $(".siginopen").css("display", "none");
    }, 1800);

    setTimeout(function () {
      $(".btnstyle.toprd").removeClass("load");
      $(".load-prd").removeClass("openprd");
      $(".popup-overlay").removeClass("open");
      $(".landingscreen").css("display", "none");
    }, 1000);
  });

  $(document).on("click", "#signin", function () {
    setTimeout(function () {
      $(".siginopen").css("display", "none");
    }, 1800);

    setTimeout(function () {
      $(".load-prd").removeClass("openprd");
      $(".landingscreen").css("display", "none");
    }, 1000);
  });
  $(document).on("click", ".submitsetup", function () {
    $(".adminsetup").removeClass("openprd");
    $(".profilesetup").addClass("openprd");
  });
  var curUrl = window.location.href;
  // notification

  $(document).on("click", ".userinfo", function () {
    $(".adminsetup").addClass("openprd");
    $(".profilesetup").removeClass("openprd");
  });

  //   $(document).on("click", ".userinfo", function () {
  //     $(".nav ul li").removeClass("active");
  //     $(".loadcontainer").load("foodavailsetup.html", function () {});
  //   });
});
